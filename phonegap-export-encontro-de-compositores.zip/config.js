define( function ( require ) {

	"use strict";

	return {
		app_slug : 'encontro-de-compositores',
		wp_ws_url : 'http://encontrolitoralsul.com.br/wp-appkit-api/encontro-de-compositores',
		wp_url : 'http://encontrolitoralsul.com.br',
		theme : 'q-android',
		version : '0.2',
		app_title : 'ECLSB Menu',
		app_platform : 'android',
		gmt_offset : -2,
		debug_mode : 'off',
		auth_key : 'se9jiri9mdyjaxw0xguw2fthq4svrunhcrwp7wz4ijhfcikdw3vmc7k3lrqfuetr',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
